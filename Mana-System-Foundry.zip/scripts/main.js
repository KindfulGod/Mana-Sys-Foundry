console.log("Система маны загружена!");
Hooks.on("ready", () => {
    console.log("Модуль успешно запущен!");
});